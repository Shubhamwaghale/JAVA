package Utils;

import java.util.Iterator;
import java.util.List;

import Custom_Exception.PetsToysException;
import POJO.PetsToy;

public class PetsToysUtils {
    private PetsToysUtils() {
        // Private constructor to prevent instantiation
    }

    public static PetsToy findToyById(List<PetsToy> toysList, int id) {
        for (PetsToy toy : toysList) {
            if (toy.getId() == id) {
                return toy;
            }
            else {
                throw new PetsToysException("Product not found with ID");
            }
        }
        return null;
    }

    public static void displayAllProducts(List<PetsToy> toysList) {
        System.out.println("======= All Products =======");
        for (PetsToy toy : toysList) {
            toy.displayDetails();
        }
        System.out.println("=============================");
    }

    public static void removeProductsNeverSoldIn9Months(List<PetsToy> toysList) {
        Iterator<PetsToy> iterator = toysList.iterator();
        while (iterator.hasNext()) {
            PetsToy toy = iterator.next();
            if (toy.isNeverSoldIn9Months()) {
                iterator.remove();
                System.out.println("Product removed as it was never sold in 9 months:");
                toy.displayDetails();
            }
            else {
                throw new PetsToysException("Product not found with ID: " + PetsToy.getIdCounter());
            }
        }
    }
}
