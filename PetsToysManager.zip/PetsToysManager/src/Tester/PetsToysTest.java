package Tester;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

import Custom_Exception.PetsToysException;
import POJO.PetsToy;
import Utils.PetsToysUtils;

public class PetsToysTest {
    private static List<PetsToy> toysList = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("======= Pets Needs Toys Admin Menu =======");
            System.out.println("1. Add new Product");
            System.out.println("2. Update stock of a Cell phone Product");
            System.out.println("3. Set discount of 10% for non-Apple Cell phone products");
            System.out.println("4. Remove products never sold in 9 months");
            System.out.println("5. Sort products by Discounts");
            System.out.println("6. Sort products by Brand");
            System.out.println("X. Exit");
            System.out.println("==========================================");
            System.out.print("Enter your choice: ");

            String choice = scanner.nextLine().trim();

            switch (choice.toUpperCase()) {
                case "1":
                    addNewProduct();
                    break;
                case "2":
                    updateStock();
                    break;
                case "3":
                    setDiscountForNonAppleProducts();
                    break;
                case "4":
                    PetsToysUtils.removeProductsNeverSoldIn9Months(toysList);
                    break;
                case "5":
                    sortProductsByDiscounts();
                    break;
                case "6":
                    sortProductsByBrand();
                    break;
                case "X":
                    System.out.println("Exiting the program. Thank you!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addNewProduct() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter product details:");

        System.out.print("Name: ");
        String name = scanner.nextLine();

        System.out.print("Brand: ");
        String brand = scanner.nextLine();

        System.out.print("OS: ");
        String os = scanner.nextLine();

        System.out.print("Material: ");
        String material = scanner.nextLine();

        System.out.print("Stock: ");
        int stock = scanner.nextInt();

        System.out.print("Price: ");
        double price = scanner.nextDouble();

        PetsToy newToy = new PetsToy(name, brand, os, material, stock, price);
        toysList.add(newToy);

        System.out.println("Product added successfully!");
        newToy.displayDetails();
    }

    private static void updateStock() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter product ID to update stock: ");
        int productId = scanner.nextInt();

        PetsToy toy = PetsToysUtils.findToyById(toysList, productId);

        if (toy != null) {
            System.out.print("Enter quantity to add/subtract: ");
            int quantity = scanner.nextInt();

            toy.updateStock(quantity);

            System.out.println("Stock updated successfully!");
            toy.displayDetails();
        } else {
            throw new PetsToysException("Product not found with ID");
        }
    }

    private static void setDiscountForNonAppleProducts() {
        for (PetsToy toy : toysList) {
            if (!toy.getBrand().equalsIgnoreCase("Apple")) {
                toy.setDiscount(10.0);
            } else {
                throw new PetsToysException("Product not found with ID");
            }
        }
        System.out.println("Discount set to 10% for all non-Apple products.");
    }

    private static void sortProductsByDiscounts() {
        toysList.sort(Comparator.comparingDouble(PetsToy::getDiscount).reversed());
        PetsToysUtils.displayAllProducts(toysList);
    }

    private static void sortProductsByBrand() {
        toysList.sort(Comparator.comparing(PetsToy::getBrand));
        PetsToysUtils.displayAllProducts(toysList);
    }
}
