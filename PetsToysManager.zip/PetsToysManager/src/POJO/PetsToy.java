package POJO;

import java.text.SimpleDateFormat;
import java.util.Date;

public class PetsToy {
    private static int idCounter = 1;
    private int id;
    private String name;
    private String brand;
    private String os;
    private String material;
    private int stock;
    private Date stockListingDate;
    private double price;
    private Date stockUpdateDate;
    private double discount;

    public PetsToy(String name, String brand, String os, String material, int stock, double price) {
        this.id = idCounter++;
        this.name = name;
        this.brand = brand;
        this.os = os;
        this.material = material;
        this.stock = stock;
        this.stockListingDate = new Date();
        this.price = price;
        this.stockUpdateDate = this.stockListingDate;
        this.discount = 0.0;
    }

    public int getId() {
        return id;
    }

    public String getBrand() {
        return brand;
    }

    // Other getters and setters...
    

    public void displayDetails() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Brand: " + brand);
        System.out.println("OS: " + os);
        System.out.println("Material: " + material);
        System.out.println("Stock: " + stock);
        System.out.println("Stock Listing Date: " + dateFormat.format(stockListingDate));
        System.out.println("Price: " + price + " INR");
        System.out.println("Stock Update Date: " + dateFormat.format(stockUpdateDate));
        System.out.println("Discount: " + discount + "%");
        System.out.println("----------------------------------");
    }


	public static int getIdCounter() {
		return idCounter;
	}

	public String getName() {
		return name;
	}

	public String getOs() {
		return os;
	}

	public String getMaterial() {
		return material;
	}

	public int getStock() {
		return stock;
	}

	public Date getStockListingDate() {
		return stockListingDate;
	}

	public double getPrice() {
		return price;
	}

	public Date getStockUpdateDate() {
		return stockUpdateDate;
	}

	public double getDiscount() {
		return discount;
	}

	public static void setIdCounter(int idCounter) {
		PetsToy.idCounter = idCounter;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public void setOs(String os) {
		this.os = os;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public void setStockListingDate(Date stockListingDate) {
		this.stockListingDate = stockListingDate;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public void setStockUpdateDate(Date stockUpdateDate) {
		this.stockUpdateDate = stockUpdateDate;
	}

	public void updateStock(int quantity) {
        this.stock += quantity;
        this.stockUpdateDate = new Date();
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public boolean isNeverSoldIn9Months() {
        long timeDifference = new Date().getTime() - stockListingDate.getTime();
        long nineMonthsInMillis = 9 * 30 * 24 * 60 * 60 * 1000L; // assuming 30 days in a month
        return timeDifference >= nineMonthsInMillis && stock == 0;
    }
    
    @Override
  	public String toString() {
  		return "PetsToy [id=" + id + ", name=" + name + ", brand=" + brand + ", os=" + os + ", material=" + material
  				+ ", stock=" + stock + ", stockListingDate=" + stockListingDate + ", price=" + price
  				+ ", stockUpdateDate=" + stockUpdateDate + ", discount=" + discount + "]";
  	}
    
}

