module PetsToysManager {
}