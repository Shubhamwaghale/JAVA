package Custom_Exception;

public class PetsToysException extends RuntimeException {
    public PetsToysException(String message) {
        super(message);
    }
}
